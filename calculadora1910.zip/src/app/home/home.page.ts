import { SourceMapGenerator } from '@angular/compiler/src/output/source_map';
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = "";
  memoria = "";

  constructor() {}

    clicar(numero: string){
    this.display = this.display + numero;
  }

  calcular(operacao: string) {
  if(this.memoria === ""){
    switch(operacao){
      case '+':
        this.memoria = this.display;
        this.display = '';
      break;
      case '-':
        this.display = 'Subtrair';
      break;
      case '*':
        this.display = 'Multiplicar';
      break;
      case '/':
        this.display = 'Dividir';
      break;
    }
  } else{
    console.log("Já tem um valor na memória: " + this.memoria);
  }

  efetuarConta(){
    const n1 = parseFloat(this.memoria);
    const n2 = parseFloat(this.display);
    const resp = n1 + n2;

    this.display = resp.toString();
  }

  limpar(){
    this.display= '';
  }
}
