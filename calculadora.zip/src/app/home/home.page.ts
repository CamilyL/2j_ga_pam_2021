import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  numero= "";

  constructor() {}

  sete(): void{
    this.numero = this.numero + '7';
  }

  oito(): void{
    this.numero = this.numero + '8';
  }

  nove(): void{
    this.numero = this.numero + '9';
  }

  quatro(): void{
    this.numero = this.numero + '4';
  }

  cinco(): void{
    this.numero = this.numero + '5';
  }

  seis(): void{
    this.numero = this.numero + '6';
  }

  um(): void{
    this.numero = this.numero + '1';
  }

  dois(): void{
    this.numero = this.numero + '2';
  }

  tres(): void{
    this.numero = this.numero + '3';
  }

  zero(): void{
    this.numero = this.numero + '0';
  }

  ponto(): void{
    this.numero = this.numero + '.';
  }
}
