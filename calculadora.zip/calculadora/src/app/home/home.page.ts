import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = "";
  memoria = "";
  operacao = "";
  auxiliar = "";
  usouPonto = false;
  estaVazio = true;

  constructor() {}

  clicar(numero: string){
    this.display = this.display + numero;

    this.verificarDisplayVazio();
  }

  verificarDisplayVazio(){
    if(this.display.length !== 0){
      this.estaVazio = false;
    }
  }

  usarPonto(){
    if(this.display === ""){
      this.display = this.display + "0";
    }

    this.display = this.display + ".";
    this.usouPonto = true;
  }

  verificarCalculo(operacao: string){
    this.operacao = operacao;
    this.memoria = this.display;
    this.display = ""; 
  }

  efetuarCalculo(){
    console.log("Memória: " + this.memoria)
    console.log("Display: " + this.display)
    console.log("Auxiliar: " + this.auxiliar)

    switch(this.operacao){
      case '+': this.somar(); break;
      case '-': this.subtrair(); break;
      case '*': this.multiplicar(); break;
      case '/': this.dividir(); break;
    } 
  }

  somar(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== "" && this.auxiliar){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 + n2;

    this.display = resp.toString();

    resp = parseFloat(this.display) - n1;

    this.auxiliar = resp.toString();
  }

  subtrair(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== "" && this.auxiliar){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 - n2;

    this.display = resp.toString();

    resp = parseFloat(this.display) - n1;

    this.auxiliar = resp.toString();
  }

  multiplicar(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== "" && this.auxiliar){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 * n2;

    this.display = resp.toString();

    resp = parseFloat(this.display) - n1;

    this.auxiliar = resp.toString();
  }

  dividir(){
    let n1 = 0;
    let n2 = 0;
    let resp = 0;

    if(this.memoria !== "" && this.auxiliar){
      n1 = parseFloat(this.memoria);
      n2 = parseFloat(this.display);
    }else{
      n1 = parseFloat(this.display);
      n2 = parseFloat(this.auxiliar);
    }
    resp = n1 / n2;

    this.display = resp.toString();

    resp = parseFloat(this.display) - n1;

    this.auxiliar = resp.toString();
  }

  limpar(){
    this.memoria = "";
    this.display = "";
    this.operacao = "";
    this.auxiliar = "";
    this.usouPonto = false;
    this.estaVazio = true;
  }
}
