import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  nome = '';
  anoNasc = null;
  mensagem = '';

  constructor() {}

  limpar(){
    this.nome = '';
    this.anoNasc = null;
    this.mensagem = '';
  }

  verificar(){
    const idade = 2021 - this.anoNasc;

    this.mensagem = this.nome + ' você tem ' + idade + ' anos.';
  }
}
